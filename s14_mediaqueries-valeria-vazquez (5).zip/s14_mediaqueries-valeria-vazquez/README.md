# S14_Mediaqueries-Valeria-Vazquez

A Pen created on CodePen.

Original URL: [https://codepen.io/VALERIA-VAZQUEZVARGAS/pen/ZYQKdqX](https://codepen.io/VALERIA-VAZQUEZVARGAS/pen/ZYQKdqX).

